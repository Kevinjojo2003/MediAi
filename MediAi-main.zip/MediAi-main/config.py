# config.py (DO NOT SHARE PUBLICLY)
# config.py - Store API keys and sensitive credentials

GEMINI_API_KEY = "AIzaSyCRWJ02CnQEyMOEgWpVPvDNpUMR6xtvd_Q"
HUGGINGFACE_TOKEN = "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"
